#include <stdio.h>

int
main ()
{
  int sayi;

  printf ("Bir sayD1 girin: ");
  scanf ("%d", &sayi);

  // SayD1nD1n C'ift ya da tek olduDunu kontrol et
  if (sayi % 2 == 0)
    {
      printf ("%d bir C'ift sayD1dD1r.\n", sayi);
    }
  else
    {
      printf ("%d bir tek sayD1dD1r.\n", sayi);
    }

  return 0;
}
